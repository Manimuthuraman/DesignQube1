<?php

$conn = mysqli_connect("localhost", "root", "","myDB");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="CREATE TABLE employees (
    first_name  VARCHAR(14)     NOT NULL,
    birth_date  DATE            NOT NULL,
    PRIMARY KEY (first_name)   
), INSERT INTO employees (`first_name`, `birth_date`) VALUES ('maniraam', '2019-10-25'), ('krish', '2019-02-27')";

$sql="SELECT first_name,birth_date from employees";

$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
            while ($row    = mysqli_fetch_array($result))
            {
		    $first_name = $row['first_name'];
            }

	
	$first_name=$row['first_name'];
	$sql="SELECT birth_date from employees";
			  				//$target_days = mktime(0,0,0,12,31,2013);// modify the birth day 12/31/2013
							$today = time();
							$diff_days = ($sql - $today);
							$days = (int)($diff_days/86400);
							print "Days till next birthday: $days days!"."\n";
					
			  			 			  			 	

mysqli_close($conn);

?>