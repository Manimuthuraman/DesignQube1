#!/usr/bin/env sh

zip -r chrome-ext.zip ./src/
