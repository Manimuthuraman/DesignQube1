function WebsiteBlocker() {
    this.blockedList = null;
    this.date = null;
    this.time = null;
    this.dayOfWeek = null;
    this.daysOfWeek = [];
    this.debug = false;
    this.useTimeGroup = true;
    this.useTimeLimit = false;
    this.redirectHistory = {};
}

(function(WB, undef) {
    WB.prototype.blocked = function(id, url) {
        this.logger('blocked - start');
        var redirect = chrome.extension.getURL('blocked.html') + '?url=' + encodeURIComponent(url);

        if (ls.get('blocked_redirect')) {
            var currentTime = new Date().getTime();
            var key = ls.get('blocked_redirect');
            var beforeTime = false;

            if (this.redirectHistory[key]) {
                beforeTime = this.redirectHistory[key].time;
                this.redirectHistory[key].count++;
                this.redirectHistory[key].time = currentTime;
            } else {
                redirect = ls.get('blocked_redirect');
                this.redirectHistory[key] = {
                    count: 1,
                    time: currentTime
                };
            }

            if (beforeTime) {
                if (currentTime - beforeTime < 1000 && 3 < this.redirectHistory[key].count) {
                    this.redirectHistory[key].count = 0;
                } else {
                    redirect = ls.get('blocked_redirect');
                }
            }
        }
        chrome.tabs.update(id, { url: redirect });
        this.logger('blocked - end');
    };
    WB.prototype.isBlocked = function(url, regexp, targetTime, currentTime, dayOfWeek) {
        this.logger('isBlocked - start');
        var pos = url.search(new RegExp(regexp, 'ig'));
        this.logger(pos);

        if (5 < pos) {
            if (this.useTimeLimit) {
                this.logger('Time Limit!');
                return false;
            }

            if (!this.useTimeGroup) {
                this.logger('Time Group!');
                return true;
            }

            this.logger(dayOfWeek);
            this.logger(this.daysOfWeek);
            if (typeof this.daysOfWeek === 'object'
                && this.matchDaysOfWeek(this.daysOfWeek, dayOfWeek)) {
                this.logger('Match days of week in');

                if (targetTime.length === 0) {
                    this.logger('Target Time!');
                    return true;
                }

                for (var i in targetTime) {
                    var current = Number(currentTime);
                    var target  = targetTime[i]
                                      .split('-')
                                      .map(function(time) {
                                          return Number(time);
                                      });

                    if (target[0] <= current && current <= target[1]) {
                        return true;
                    }
                }
            }
        }

        this.logger('isBlocked - end');
        return false;
    };
    WB.prototype.matchDaysOfWeek = function(targetDaysOfWeek, currentDayOfWeek) {
        this.logger('matchDaysOfWeek - in');

        if (typeof targetDaysOfWeek === 'object') {
             for (var weekNum in targetDaysOfWeek) {
                 if (targetDaysOfWeek[weekNum] == currentDayOfWeek) {
                     return true;
                 }
             }
        }

        return false;
    };
    WB.prototype.toString = function(list) {
        var result = [];

        for (var key in list) {
            var row = list[key];
            result.push(row.url + ' ' + row.time.join(','));
        }

        return result.join('\n');
    };
    WB.prototype.toFormat = function(text) {
        var rows, row, URLTime, line, BLOCKED = [];
        rows = text.split('\n');

        if (rows.length > 0) {
            for (var i = 0; i < rows.length; i++) {
                row = rows[i].trim();
                if (!row) continue;
                URLTime = row.split(' ');
                line = { url: URLTime[0], time: [], regexp: null };

                if (URLTime.length === 2) {
                    line.time = URLTime[1].split(',');
                }
                else if (URLTime.length > 2) {
                    line.time = row.replace(/\s/g, '').replace(URLTime[0], '').split(',');
                }

                line.regexp = URLTime[0].replace(/\./g, '\\.');
                BLOCKED.push(line);
            }
        }

        return BLOCKED;
    };
    WB.prototype.makeTime = function() {
        this.date = new Date();
        var hh = this.date.getHours();
        var mm = this.date.getMinutes();

        this.dayOfWeek = this.date.getDay();

        if (hh < 10) {
            hh = '0' + hh;
        }

        if (mm < 10) {
            mm = '0' + mm;
        }

        return this.time = hh.toString() + mm.toString();
    };
    WB.prototype.checkUrl = function(id, url, testmode) {
        this.blockedList = ls.get('blocked_list');
        var currentTime = null;

        if (this.blockedList) {
            currentTime = this.makeTime();
            this.useTimeGroup = ls.get('flag-timegroup_function');
            this.daysOfWeek = ls.get('days_of_week');

            for (var key in this.blockedList) {
                this.logger(this.blockedList[key].regexp);
                if (this.isBlocked(url, this.blockedList[key].regexp, this.blockedList[key].time, currentTime, this.dayOfWeek)) {
                    if (testmode) {
                        return true;
                    }
                    this.blocked(id, url);
                    break;
                }
            }
        }

        return false;
    };
    WB.prototype.generateRandomString = function(digit, number, alphabetLower, alphabetUpper) {
        var pool = '', code = '';
        if (number)        pool += '1234567890';
        if (alphabetLower) pool += 'abcdefghijklmnopqrstuvwxyz';
        if (alphabetUpper) pool += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        for (var i = 0; i < digit; i++) {
            code += pool.substr(Math.random() * pool.length, 1);
        }

        return code;
    };
    WB.prototype.matchPassphrase = function(src, dest) {
        return src === dest;
    };
WB.prototype.setTimeLimit = function(sec) {
        var that = this;
        that.useTimeLimit = true;
        window.setTimeout(function() {
            that.useTimeLimit = false;
        }, sec * 1000);
    };
    WB.prototype.logger = function(a) {
        if (this.debug) {
            console.debug('{WebsiteBlocker Log}', a);
        }
    };

    WB.prototype.run = function(tab) {
        this.logger(tab);

        if (!ls.get('flag-block_function')) {
            return false;
        }

        if (tab.url.search(/https?:/) === 0) {
            this.checkUrl(tab.id, tab.url, false);
        }

        return true;
    };

    WB.prototype.toFormatDaysOfWeekToString = function(days) {
        var daysOfWeek = [];
        days.each(function(i, el){
            daysOfWeek.push($(el).val());
        });

        return daysOfWeek.toString();
    };
    WB.prototype.toFormatDaysOfWeekToArray = function(days) {
        return days ? days.split(',') : [];
    };

})(WebsiteBlocker);
