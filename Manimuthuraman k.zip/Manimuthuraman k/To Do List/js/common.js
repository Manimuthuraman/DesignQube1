define([
	'text',
	'jquery',
	'underscore',
	'backbone',
	'model/todo',
	'collection/todos',
	'view/stats',
	'view/todoview',
	'view/todosview',
	'text!template/stats.html',
	'text!template/todo.html'],
function () {
});