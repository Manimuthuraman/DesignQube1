<?php
$users = array(
	'admin' => 'pass',
	'username' => 'password'
);
?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">

	<title>A Todo List</title>
	
	<link rel="stylesheet" href="css/forgetmenot.css"/>

	<script data-main="js/main" src="js/libs/require.js"></script>
</head>
<body>

	<div class="container" id="app">
		<header class="clearfix">
			<h1>A todo list</h1>
			<img src="images/new.png" value="Create New" id="createNew" class="createNew" />
			
			<nav id="stats" class="clearfix">
			</nav>
		</header>
		
		<ul class="todoList fmn-todos" id="todoItemsList">
			<script type="text/javascript">
			var json = <?php require_once('api.php'); ?>;
			</script>
		</ul>

		<footer>
			
		</footer>
	</div>

</body>
</html>